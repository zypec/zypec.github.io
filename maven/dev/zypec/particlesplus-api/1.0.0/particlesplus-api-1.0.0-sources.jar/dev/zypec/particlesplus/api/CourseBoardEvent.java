package dev.zypec.particlesplus.api;

import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

/**
 * A course's best times have changed: a run beat a player's own best, the course was deleted, or the
 * times were read again from the database. Called on the server's thread once
 * {@link ParticlesPlusAPI#leaderboard(String, int)} already answers with the new times.
 */
public final class CourseBoardEvent extends Event {

    public CourseBoardEvent(String course) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * The course's key, or null when every course's times were read again.
     */
    public String getCourse() {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    @Override
    public @NotNull HandlerList getHandlers() {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    public static HandlerList getHandlerList() {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }
}
