package dev.zypec.particlesplus.api;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.function.Predicate;

/**
 * What another plugin may ask of Particles+ and have it do, without typing a command for a player or
 * opening a menu. Call it from the server's thread, or on Folia from the thread that owns the player.
 *
 * <p>Particles+ reads its effects and courses off the main thread after it is enabled, so a plugin
 * that starts with the server waits for {@link #isReady()} before it asks for them.
 */
public final class ParticlesPlusAPI {

    /**
     * What came of {@link #select(Player, String, boolean)}.
     */
    public enum Selection {
        SELECTED,
        UNKNOWN_EFFECT,
        NO_PERMISSION,
        /**
         * Particles+ has not finished reading its effects, or the player's saved choices, yet.
         */
        NOT_READY
    }

    /**
     * One place on a course's board.
     */
    public record Time(String player, long millis) {

        /**
         * The time as Particles+ writes it everywhere else, {@code 1:04.250}.
         */
        public String formatted() {
            throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
        }
    }

    public static boolean isReady() {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Every effect's key, in the order of effects.yml.
     */
    public static List<String> effects() {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Whether Particles+ has an effect with this key. False until {@link #isReady()}.
     */
    public static boolean hasEffect(String effect) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * An effect's name as MiniMessage, in the colors it is shown in standing still, or null where
     * there is no such effect.
     */
    public static String displayName(String effect) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    public static Selection select(Player player, String effect) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Puts an effect on a player, as choosing it from the menu does but without a message: the plugin
     * that asks says what it wants to.
     *
     * @param checkPermission whether the player's own permission for the effect is asked for
     */
    public static Selection select(Player player, String effect, boolean checkPermission) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * The key of the effect a player wears, or null.
     */
    public static String selected(Player player) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Takes a player's effect off and forgets their mixes.
     */
    public static void clear(Player player) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Whether an effect can be drawn standing at a place, with {@link #show(String, String, Location)}.
     */
    public static boolean canShow(String effect) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Draws an effect at a place, as a static effect is, under an id of the caller's choosing. It is
     * not written to static_effects.yml: it lasts until {@link #hide(String)}, a restart or a
     * {@code /prt reload}, and {@link #isShown(String)} says whether it still does.
     *
     * @return false where there is no such effect or it has no STATIC handler
     */
    public static boolean show(String id, String effect, Location location) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    public static boolean isShown(String id) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Stops what {@link #show(String, String, Location)} drew under this id. A static effect an admin
     * started, which is saved, is left alone.
     */
    public static void hide(String id) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Every course's key, in the order of courses.yml.
     *
     * @return List of every course's key.
     */
    public static List<String> courses() {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Whether Particles+ has a course with this key, whatever case it is asked in.
     * False until {@link #isReady()}.
     *
     * @return True if there is a course with this key, false otherwise.
     */
    public static boolean hasCourse(String course) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * A course's title as MiniMessage.
     *
     * @return Unparsed MiniMessage text, or null where there is no such course.
     */
    public static String courseTitle(String course) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * @return How many places a course's best times are listed to, its {@code top} setting, or 0 where
     *         there is no such course.
     */
    public static int topSize(String course) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * A course's best times, fastest first, at most {@code size} of them. Answered from the copy of
     * the table Particles+ keeps in memory, so it may be asked as often as a hologram wants;
     * {@link CourseBoardEvent} says when it has changed.
     */
    public static List<Time> leaderboard(String course, int size) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * A player's own best time on a course in milliseconds, or null where they have not finished it.
     */
    public static Long best(String course, UUID player) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Has the effects that react to hitting or killing a player react to these entities too, a
     * mannequin standing in for a player, say. Added for as long as the server runs; a plugin that is
     * disabled takes its own back with {@link #stopTreatingAsPlayer(Predicate)}.
     */
    public static void treatAsPlayer(Predicate<Entity> which) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    public static void stopTreatingAsPlayer(Predicate<Entity> which) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    /**
     * Whether an entity counts as a player for the effects that tell a player from a mob.
     */
    public static boolean isPlayerLike(Entity entity) {
        throw new UnsupportedOperationException("Particles+ supplies this when the server runs");
    }

    private ParticlesPlusAPI() {
    }
}
