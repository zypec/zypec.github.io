package dev.zypec.editorkit;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.regex.Pattern;

/**
 * A web editor reached from any browser without a port opened on the server: the plugin dials out
 * to the relay (relay/worker.js), which serves the editor's page, and the page meets the plugin
 * there. Each link carries a key of its own in its fragment, which no server ever sees; what passes
 * through the relay is sealed with it, so the relay only ever carries bytes it cannot read.
 *
 * <p>A request that arrives is opened, checked and asked of the editor's own HTTP server on this
 * machine, with its token in {@code Authorization: Bearer}, and the answer goes back in pieces as it
 * is read, which is what lets an endless stream through. Who asked for the link travels with every
 * request in {@link #WHO_HEADER} and {@link #WHO_ID_HEADER}, and the public demo's requests carry
 * {@link #DEMO_HEADER}; the local server trusts them because only this link knows the token. The
 * page's tunnel (web/net/relay.js) is the other end.
 *
 * <p>A link opens one tab. The first tab to show its key claims it with a secret of its own, and
 * the key then answers that tab alone, reloads included; a link nobody opened within two minutes is
 * dead, and with a lifetime an opened one stops working that long after it was opened. Every request
 * carries the number the server handed the tab when it connected, so a message the relay kept and
 * sent again on another connection is refused.
 */
public final class RelayLink implements WebSocket.Listener {

    /** The name of the player who asked for the link, URL-encoded. */
    public static final String WHO_HEADER = "X-Editor-Who";
    /** The id of the player who asked for the link. */
    public static final String WHO_ID_HEADER = "X-Editor-Who-Id";
    /** Present, as {@code 1}, on every request of the public demo. */
    public static final String DEMO_HEADER = "X-Editor-Demo";

    /**
     * The close code a tab is sent when its link is taken back, which the page tells apart from a
     * link that was used up.
     */
    public static final int REVOKED = 4401;
    /** The close code a tab is sent when its link was let go of for going unused. */
    public static final int IDLE = 4408;

    /** The demo's session, the editor anybody opens at {@code <relay>/#demo}. */
    public static final String DEMO_SESSION = "demo";

    private static final Gson GSON = new Gson();
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final byte OPENED = 1, DATA = 2, CLOSED = 3;
    /**
     * The close code the relay sends a plugin whose session another plugin has taken. Two demo
     * servers each dialing again on it would take the demo from each other for good, so the one
     * displaced lets it go.
     */
    private static final int REPLACED = 4409;
    private static final byte[] TOWARD = "B".getBytes(StandardCharsets.US_ASCII), BACK = "P".getBytes(StandardCharsets.US_ASCII);

    /**
     * Pieces of an answer, raw. Base64 and the seal bring one to about 350 KiB, under the megabyte
     * a relay message may be.
     */
    private static final int PIECE = 256 * 1024;
    private static final int MAX_BODY = 4 * 1024 * 1024;
    private static final long UNCLAIMED_MILLIS = 120_000;

    /**
     * A socket nobody writes to can die without either end being told: a host's NAT forgets it and
     * the relay goes on sending a new tab's hello into nothing, which the tab waits on for good. A
     * ping every so often keeps the way open, and a relay silent for longer than two of them, not
     * even a pong, is taken for gone and dialed again.
     */
    private static final long PING_SECONDS = 30;
    private static final long SILENT_MILLIS = 75_000;
    private static final Set<String> METHODS = Set.of("GET", "HEAD", "POST", "PUT", "PATCH", "DELETE");
    private static final Set<String> ALWAYS_CARRIED = Set.of("content-type", "accept");
    private static final Set<String> ALWAYS_RETURNED = Set.of("content-type", "cache-control");
    private static final Pattern PATH = Pattern.compile("^/[A-Za-z0-9._~!$&'()*+,;=:@%/?-]*$");
    private static final Pattern ADDRESS = Pattern.compile("^[0-9A-Fa-f.:]{2,45}$");
    private static final Pattern COUNTRY = Pattern.compile("^[A-Z]{2}$");

    /**
     * A socket to Cloudflare left open for hours is dropped now and then (the object holding it is
     * restarted or moved) and dialed again within seconds, and saying so twice in the console
     * each time read as something being wrong. A drop is said only once it has lasted this long,
     * and being back only after a drop that was said.
     */
    private static final long QUIET_SECONDS = 30;

    private final String relay;
    private final String local;
    private final String token;
    private final int api;
    private final Consumer<String> say;
    private final Set<String> carried;
    private final Set<String> returned;
    private final Predicate<String> streaming;
    private final Consumer<Boolean> opened;
    /**
     * Sixty-four bits: the session is only where the relay sends a browser, and a guessed one is
     * worth nothing without a key, so it is kept short for the link's sake.
     */
    private final String session;
    private final String demoSecret;
    private final Runnable displaced;
    private final String claim = hex(bytes(32), 0, 32);
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private final ExecutorService readers;

    private final Map<String, Grant> grants = new ConcurrentHashMap<>();
    private final AtomicInteger numbered = new AtomicInteger();
    private final Map<Integer, Connection> connections = new ConcurrentHashMap<>();
    private final ByteArrayOutputStream partial = new ByteArrayOutputStream();

    /**
     * What arrives, handled in order on a thread of its own: answering waits for the socket, and
     * the socket's own thread must not be the one waiting.
     */
    private final ExecutorService inbox;
    private final ScheduledExecutorService pinger;

    private volatile WebSocket socket;
    private volatile long heard;
    private volatile boolean running = true;
    private volatile boolean announced;
    private volatile long downSince;
    private volatile String downWhy;
    private volatile boolean downSaid;
    private CompletableFuture<?> sending = CompletableFuture.completedFuture(null);
    private int retries;

    /**
     * Counts the dials, so that a dial waiting out its delay is dropped when another has been made
     * in its place: two sockets on one session take each other's place at the relay in turn.
     */
    private final AtomicInteger dials = new AtomicInteger();
    private volatile boolean dialing;

    /**
     * How long an opened link may go unused before it is let go of, in milliseconds, or 0 for as long
     * as the editor is open.
     */
    private volatile long idleMillis;
    private volatile BiConsumer<Integer, Long> idleTold;

    private RelayLink(Builder builder) {
        this.relay = trimSlash(builder.relay);
        this.local = trimSlash(Objects.requireNonNull(builder.local, "the local server's address"));
        this.token = Objects.requireNonNull(builder.token, "the local server's token");
        this.api = builder.api;
        this.say = builder.say;
        this.carried = union(ALWAYS_CARRIED, builder.carried);
        this.returned = union(ALWAYS_RETURNED, builder.returned);
        this.streaming = builder.streaming;
        this.opened = builder.opened;
        this.demoSecret = builder.demoSecret;
        this.displaced = builder.displaced;
        this.session = demoSecret == null ? token(8) : DEMO_SESSION;
        this.readers = Executors.newCachedThreadPool(daemon(builder.product + " editor relay"));
        this.inbox = Executors.newSingleThreadExecutor(daemon(builder.product + " editor relay inbox"));
        this.pinger = Executors.newSingleThreadScheduledExecutor(daemon(builder.product + " editor relay ping"));
        if (demoSecret != null) {
            var grant = new Grant(builder.demoKey, keyId(builder.demoKey), Long.MAX_VALUE, Map::of, 0, numbered.incrementAndGet(),
                    null, null, true);
            grant.opened = System.currentTimeMillis();
            grants.put(grant.id, grant);
        }
        connect(dials.incrementAndGet());
        pinger.scheduleAtFixedRate(this::ping, PING_SECONDS, PING_SECONDS, TimeUnit.SECONDS);
    }

    /**
     * A link through the relay at this address, https://…
     */
    public static Builder to(String relay) {
        return new Builder(relay);
    }

    /**
     * A new link, good for one tab.
     *
     * @param owner    the player who asked for it, or null for the console
     * @param ownerId  that player's id, or null for the console
     * @param lifetime how long it keeps working once a tab has opened it, in milliseconds, or 0
     *                 for as long as the editor is open
     * @param hello    what the server's hello carries besides the protocol's own fields, read when a
     *                 tab opens the link (a skin fetched meanwhile, say)
     */
    public String link(String owner, UUID ownerId, long lifetime, Supplier<Map<String, ?>> hello) {
        var key = bytes(16);
        var grant = new Grant(key, keyId(key), System.currentTimeMillis() + UNCLAIMED_MILLIS, hello == null ? Map::of : hello,
                lifetime, numbered.incrementAndGet(), owner, ownerId, false);
        forget();
        grants.put(grant.id, grant);
        if (socket == null && !dialing) {
            retries = 0;
            connect(dials.incrementAndGet());
        }
        return relay + "/#" + session + "." + encode(key);
    }

    /**
     * The links still good, oldest first: one nobody opened in time, or whose lifetime is over,
     * is let go of here.
     */
    public List<Link> links() {
        forget();
        var listed = new ArrayList<Link>();
        for (var grant : grants.values()) {
            var tabs = 0;
            for (var connection : connections.values())
                if (connection.grant == grant) tabs++;
            var open = grant.tab != null || grant.shared;
            listed.add(new Link(grant.number, grant.owner, grant.ownerId, open, open ? grant.opened : grant.expires,
                    tabs, grant.address, grant.country));
        }
        listed.sort(Comparator.comparingInt(Link::number));
        return listed;
    }

    /**
     * Takes a link back: its key answers nothing from now on and every tab holding it is closed.
     *
     * @return false where there is no such link
     */
    public boolean revoke(int number) {
        for (var grant : grants.values())
            if (grant.number == number) {
                takeBack(grant);
                return true;
            }
        return false;
    }

    /**
     * Takes back every link this player asked for, the way {@link #revoke} takes back one.
     *
     * @return how many there were
     */
    public int revokeAll(UUID ownerId) {
        var taken = 0;
        for (var grant : List.copyOf(grants.values()))
            if (!grant.shared && ownerId.equals(grant.ownerId)) {
                takeBack(grant);
                taken++;
            }
        return taken;
    }

    private void takeBack(Grant grant) {
        grants.remove(grant.id);
        try {
            inbox.execute(() -> {
                for (var connection : List.copyOf(connections.values()))
                    if (connection.grant == grant) connection.shut(REVOKED);
            });
        } catch (RuntimeException closed) {
        }
    }

    /**
     * How long an opened link may go unused before it is let go of, in minutes, or 0 for as long as
     * the editor is open: a link left open in a tab overnight kept working while anyone else used
     * the editor, and on the public demo, which never closes, for good.
     */
    public void idle(int minutes) {
        idleMillis = Math.max(0, minutes) * 60_000L;
    }

    /**
     * Told the number of a link let go of for going unused, and after how many minutes.
     */
    public void onIdle(BiConsumer<Integer, Long> told) {
        idleTold = told;
    }

    public void close() {
        running = false;
        grants.clear();
        connections.clear();
        var open = socket;
        socket = null;
        if (open != null) open.sendClose(WebSocket.NORMAL_CLOSURE, "The editor closed");
        readers.shutdownNow();
        inbox.shutdownNow();
        pinger.shutdownNow();
    }

    private void forget() {
        var now = System.currentTimeMillis();
        grants.values().removeIf(old -> old.tab == null ? old.expires < now : old.until > 0 && old.until < now);
        var limit = idleMillis;
        if (limit <= 0) return;
        for (var grant : List.copyOf(grants.values())) {
            if (grant.shared || grant.tab == null || now - grant.used < limit) continue;
            grants.remove(grant.id);
            var told = idleTold;
            if (told != null) told.accept(grant.number, limit / 60_000L);
            try {
                inbox.execute(() -> {
                    for (var connection : List.copyOf(connections.values()))
                        if (connection.grant == grant) connection.shut(IDLE);
                });
            } catch (RuntimeException closed) {
                return;
            }
        }
    }

    private void ping() {
        forget();
        var open = socket;
        if (open == null) return;
        if (System.currentTimeMillis() - heard > SILENT_MILLIS) {
            socket = null;
            open.abort();
            retry("the relay stopped answering");
            return;
        }
        try {
            open.sendPing(ByteBuffer.allocate(0));
        } catch (RuntimeException closing) {
        }
    }

    private void connect(int dial) {
        if (!running || dial != dials.get()) return;
        dialing = true;
        var address = URI.create(relay.replaceFirst("^http", "ws") + "/session/" + session + "/plugin?claim=" + claim
                + (demoSecret == null ? "" : "&demo=" + URLEncoder.encode(demoSecret, StandardCharsets.UTF_8)));
        http.newWebSocketBuilder().connectTimeout(Duration.ofSeconds(10)).buildAsync(address, this)
                .whenComplete((open, failure) -> {
                    if (dial != dials.get()) return;
                    dialing = false;
                    if (failure != null) retry("couldn't reach " + relay + ": " + rootMessage(failure));
                });
    }

    /**
     * Tries again a little later each time, up to a minute apart, for as long as the editor is open.
     */
    private void retry(String why) {
        socket = null;
        connections.clear();
        if (!running) return;
        downWhy = why;
        if (downSince == 0) {
            var since = downSince = System.currentTimeMillis();
            try {
                pinger.schedule(() -> {
                    if (running && socket == null && downSince == since && !downSaid) {
                        downSaid = true;
                        say.accept(downWhy);
                    }
                }, QUIET_SECONDS, TimeUnit.SECONDS);
            } catch (RuntimeException closing) {
            }
        }
        var wait = Math.min(60, 1L << Math.min(6, retries++));
        var dial = dials.incrementAndGet();
        CompletableFuture.delayedExecutor(wait, TimeUnit.SECONDS).execute(() -> connect(dial));
    }

    @Override
    public void onOpen(WebSocket webSocket) {
        heard = System.currentTimeMillis();
        socket = webSocket;
        retries = 0;
        downSince = 0;
        if (!announced || downSaid) say.accept(null);
        announced = true;
        downSaid = false;
        webSocket.request(1);
    }

    @Override
    public CompletionStage<?> onBinary(WebSocket webSocket, ByteBuffer data, boolean last) {
        heard = System.currentTimeMillis();
        var bytes = new byte[data.remaining()];
        data.get(bytes);
        partial.write(bytes, 0, bytes.length);
        if (last) {
            var whole = partial.toByteArray();
            partial.reset();
            try {
                inbox.execute(() -> {
                    try {
                        received(whole);
                    } catch (RuntimeException ignored) {
                    }
                });
            } catch (RuntimeException closed) {
                return null;
            }
        }
        webSocket.request(1);
        return null;
    }

    @Override
    public CompletionStage<?> onPong(WebSocket webSocket, ByteBuffer message) {
        heard = System.currentTimeMillis();
        webSocket.request(1);
        return null;
    }

    /**
     * Only the socket in use is dialed again. One already replaced, or given up on for silence,
     * still says it closed, and acting on it would drop the connection that took its place and dial
     * a second one beside it.
     */
    @Override
    public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
        if (webSocket == socket && demoSecret != null && statusCode == REPLACED) {
            running = false;
            socket = null;
            connections.clear();
            displaced.run();
            return null;
        }
        if (webSocket == socket)
            retry("the relay closed the connection (" + statusCode + (reason.isEmpty() ? "" : ", " + reason) + ")");
        return null;
    }

    @Override
    public void onError(WebSocket webSocket, Throwable error) {
        if (webSocket == socket) retry("lost the relay: " + rootMessage(error));
    }

    private void received(byte[] frame) {
        if (frame.length < 5) return;
        var conn = ByteBuffer.wrap(frame, 1, 4).getInt();
        switch (frame[0]) {
            case OPENED -> {
                var connection = new Connection(conn);
                if (frame.length > 5) where(connection, new String(frame, 5, frame.length - 5, StandardCharsets.UTF_8));
                connections.put(conn, connection);
            }
            case CLOSED -> {
                var gone = connections.remove(conn);
                if (gone != null) gone.readers.values().forEach(RelayLink::quietly);
            }
            case DATA -> {
                var connection = connections.get(conn);
                if (connection != null) connection.received(frame, 5);
            }
            default -> {
            }
        }
    }

    /**
     * Where the relay says a tab is. Nothing checks it but its shape, which is what keeps it from
     * carrying anything into the chat line that shows it.
     */
    private static void where(Connection connection, String said) {
        try {
            var where = GSON.fromJson(said, JsonObject.class);
            var address = text(where, "ip");
            var country = text(where, "country");
            if (address != null && ADDRESS.matcher(address).matches()) connection.address = address;
            if (country != null && COUNTRY.matcher(country).matches()) connection.country = country;
        } catch (RuntimeException unreadable) {
        }
    }

    /**
     * One browser tab through the relay.
     */
    private final class Connection {
        private final int conn;
        private final Map<Integer, InputStream> readers = new ConcurrentHashMap<>();
        private volatile Grant grant;
        private String nonce;
        private String address;
        private String country;
        /**
         * The request numbers this tab has used. The relay cannot read a request but could send one
         * it carried again on the same connection, and a save run twice is not the save somebody
         * made. The page counts up, so a number at or below {@code floor} is an old one.
         */
        private final Set<Integer> asked = new HashSet<>();
        private int floor = Integer.MIN_VALUE;

        private Connection(int conn) {
            this.conn = conn;
        }

        private void received(byte[] frame, int from) {
            if (frame.length - from < 8 + 12 + 16) return;
            var id = hex(frame, from, 8);
            var key = grants.get(id);
            if (key == null || (grant != null && grant != key)) {
                shut(4403);
                return;
            }
            JsonObject message;
            try {
                message = GSON.fromJson(new String(open(key.key, frame, from + 8), StandardCharsets.UTF_8), JsonObject.class);
            } catch (GeneralSecurityException | RuntimeException forged) {
                shut(4403);
                return;
            }
            var kind = text(message, "t");
            if (grant == null) {
                if (!"hi".equals(kind)) return;
                var tab = text(message, "tab");
                if (tab == null || tab.length() < 16) return;
                if (key.shared) told(true);
                else synchronized (key) {
                    if (key.tab == null && key.expires < System.currentTimeMillis()) {
                        shut(4403);
                        return;
                    }
                    if (key.tab == null) {
                        key.tab = tab;
                        key.opened = System.currentTimeMillis();
                        key.used = key.opened;
                        if (key.lifetime > 0) key.until = key.opened + key.lifetime;
                        told(false);
                    }
                    else if (!MessageDigest.isEqual(key.tab.getBytes(StandardCharsets.UTF_8), tab.getBytes(StandardCharsets.UTF_8))) {
                        shut(4403);
                        return;
                    }
                }
                key.address = address;
                key.country = country;
                grant = key;
                nonce = token(16);
                var hello = new LinkedHashMap<String, Object>();
                Map<String, ?> extra;
                try {
                    extra = key.hello.get();
                } catch (RuntimeException failed) {
                    extra = null;
                }
                if (extra != null) extra.forEach((name, value) -> {
                    if (value != null) hello.put(name, value);
                });
                hello.put("t", "hello");
                hello.put("nonce", nonce);
                hello.put("v", 1);
                hello.put("api", api);
                if (key.owner != null) hello.put("who", key.owner);
                send(this, hello);
                return;
            }
            if (!nonce.equals(text(message, "nonce")) || (key.until > 0 && key.until < System.currentTimeMillis())) {
                shut(4403);
                return;
            }
            var request = message.has("id") ? message.get("id").getAsInt() : -1;
            if ("abort".equals(kind)) quietly(readers.remove(request));
            else if ("req".equals(kind)) {
                if (!fresh(request)) {
                    shut(4403);
                    return;
                }
                var path = text(message, "path");
                if (path == null || !streaming.test(path)) key.used = System.currentTimeMillis();
                forward(this, request, message);
            }
        }

        private boolean fresh(int request) {
            if (request <= floor || !asked.add(request)) return false;
            if (asked.size() > 1024) {
                floor = request - 512;
                asked.removeIf(old -> old <= floor);
            }
            return true;
        }

        private void shut(int code) {
            connections.remove(conn);
            readers.values().forEach(RelayLink::quietly);
            var frame = ByteBuffer.allocate(7).put(CLOSED).putInt(conn).putShort((short) code).array();
            write(frame);
        }
    }

    private void told(boolean demo) {
        try {
            opened.accept(demo);
        } catch (RuntimeException ignored) {
        }
    }

    /**
     * Asks the editor's own server what the browser asked, with the token the browser never had,
     * and streams the answer back.
     */
    private void forward(Connection connection, int id, JsonObject message) {
        var method = String.valueOf(text(message, "method")).toUpperCase(Locale.ROOT);
        var path = text(message, "path");
        if (!METHODS.contains(method) || path == null || !PATH.matcher(path).matches() || path.startsWith("//")) {
            failed(connection, id, "Not something the editor answers");
            return;
        }
        byte[] body = null;
        if (message.has("body") && !message.get("body").isJsonNull()) {
            body = Base64.getDecoder().decode(message.get("body").getAsString());
            if (body.length > MAX_BODY) {
                failed(connection, id, "Too large");
                return;
            }
        }

        var request = HttpRequest.newBuilder(URI.create(local + path)).timeout(Duration.ofMinutes(10));
        if (message.has("headers") && message.get("headers").isJsonObject())
            for (var header : message.getAsJsonObject("headers").entrySet())
                if (carried.contains(header.getKey().toLowerCase(Locale.ROOT)) && header.getValue().isJsonPrimitive())
                    request.header(header.getKey(), header.getValue().getAsString());
        request.header("Authorization", "Bearer " + token);
        var grant = connection.grant;
        if (grant.shared) request.header(DEMO_HEADER, "1");
        else {
            if (grant.owner != null) request.header(WHO_HEADER, URLEncoder.encode(grant.owner, StandardCharsets.UTF_8));
            if (grant.ownerId != null) request.header(WHO_ID_HEADER, grant.ownerId.toString());
        }
        request.method(method, body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofByteArray(body));
        if (streaming.test(path)) request.timeout(Duration.ofDays(1));

        http.sendAsync(request.build(), HttpResponse.BodyHandlers.ofInputStream()).whenComplete((response, failure) -> {
            if (failure != null) {
                failed(connection, id, rootMessage(failure));
                return;
            }
            var stream = response.body();
            connection.readers.put(id, stream);
            try {
                readers.execute(() -> stream(connection, id, response, stream));
            } catch (RuntimeException closed) {
                quietly(stream);
            }
        });
    }

    private void stream(Connection connection, int id, HttpResponse<InputStream> response, InputStream stream) {
        try (stream) {
            var head = new LinkedHashMap<String, Object>();
            head.put("t", "head");
            head.put("id", id);
            head.put("status", response.statusCode());
            var headers = new LinkedHashMap<String, String>();
            response.headers().map().forEach((name, values) -> {
                if (returned.contains(name.toLowerCase(Locale.ROOT)) && !values.isEmpty()) headers.put(name, values.get(0));
            });
            head.put("headers", headers);
            send(connection, head);

            var buffer = new byte[PIECE];
            int read;
            while ((read = readSome(stream, buffer)) > 0) {
                if (!connections.containsKey(connection.conn)) return;
                var piece = new LinkedHashMap<String, Object>();
                piece.put("t", "data");
                piece.put("id", id);
                piece.put("b64", Base64.getEncoder().encodeToString(Arrays.copyOf(buffer, read)));
                send(connection, piece);
            }
            send(connection, Map.of("t", "end", "id", id));
        } catch (IOException cut) {
            if (connection.readers.containsKey(id)) failed(connection, id, "The answer was cut short");
        } finally {
            connection.readers.remove(id);
        }
    }

    /**
     * Reads what has arrived, up to a buffer's worth, without waiting for the buffer to fill: a
     * stream that writes a few hundred bytes a second has to reach the page as it comes.
     */
    private static int readSome(InputStream stream, byte[] buffer) throws IOException {
        var first = stream.read(buffer, 0, buffer.length);
        if (first <= 0) return first;
        var total = first;
        while (total < buffer.length && stream.available() > 0) {
            var more = stream.read(buffer, total, Math.min(buffer.length - total, stream.available()));
            if (more <= 0) break;
            total += more;
        }
        return total;
    }

    private void failed(Connection connection, int id, String why) {
        send(connection, Map.of("t", "error", "id", id, "message", why == null ? "Failed" : why));
    }

    private void send(Connection connection, Map<String, ?> message) {
        var grant = connection.grant;
        if (grant == null) return;
        try {
            var sealed = seal(grant.key, GSON.toJson(message).getBytes(StandardCharsets.UTF_8));
            var frame = ByteBuffer.allocate(5 + sealed.length).put(DATA).putInt(connection.conn).put(sealed).array();
            write(frame);
        } catch (GeneralSecurityException impossible) {
            throw new IllegalStateException(impossible);
        }
    }

    /**
     * One message on the socket at a time, in order: the JDK's WebSocket refuses a send while the
     * one before it is still going.
     */
    private synchronized void write(byte[] frame) {
        var open = socket;
        if (open == null) return;
        sending = sending.handle((done, failure) -> null)
                .thenCompose(nothing -> open.sendBinary(ByteBuffer.wrap(frame), true));
        sending.join();
    }

    static byte[] seal(byte[] key, byte[] plain) throws GeneralSecurityException {
        var iv = bytes(12);
        var cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, iv));
        cipher.updateAAD(BACK);
        var sealed = cipher.doFinal(plain);
        return ByteBuffer.allocate(8 + 12 + sealed.length).put(keyId(key)).put(iv).put(sealed).array();
    }

    static byte[] open(byte[] key, byte[] frame, int from) throws GeneralSecurityException {
        var cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, frame, from, 12));
        cipher.updateAAD(TOWARD);
        return cipher.doFinal(frame, from + 12, frame.length - from - 12);
    }

    /**
     * The first eight bytes of the key's hash: what tells the server which link a message was
     * sealed with, without telling anybody the key.
     */
    static byte[] keyId(byte[] key) {
        try {
            return Arrays.copyOf(MessageDigest.getInstance("SHA-256").digest(key), 8);
        } catch (GeneralSecurityException impossible) {
            throw new IllegalStateException(impossible);
        }
    }

    /**
     * A relay link as an admin sees it: who asked for it, whether a tab has opened it, and where that
     * tab is. Where comes from the relay, which sees the browser's address, and is shown, never
     * trusted.
     *
     * @param owner   the player who asked for it, or null for the console
     * @param ownerId that player's id, or null for the console
     * @param since   when a tab opened it, or when it dies unopened
     * @param tabs    the connections open with it right now
     * @param address the browser's address, or null where the relay did not say
     * @param country the two-letter country the relay placed it in, or null
     */
    public record Link(int number, String owner, UUID ownerId, boolean opened, long since, int tabs, String address, String country) {
    }

    /**
     * What a link is opened with. Only the relay, the local server and its token are needed.
     */
    public static final class Builder {
        private final String relay;
        private String local;
        private String token;
        private String product = "Editor";
        private int api = 1;
        private Consumer<String> say = said -> {
        };
        private final Set<String> carried = new HashSet<>();
        private final Set<String> returned = new HashSet<>();
        private Predicate<String> streaming = path -> false;
        private Consumer<Boolean> opened = demo -> {
        };
        private String demoSecret;
        private byte[] demoKey;
        private Runnable displaced = () -> {
        };

        private Builder(String relay) {
            this.relay = Objects.requireNonNull(relay, "the relay's address");
        }

        /**
         * The editor's own server on this machine, http://127.0.0.1:…/, and the token it wants in
         * {@code Authorization: Bearer}.
         */
        public Builder local(String address, String token) {
            this.local = address;
            this.token = token;
            return this;
        }

        /** The product's name, for the names of the link's threads. */
        public Builder product(String name) {
            this.product = name;
            return this;
        }

        /**
         * The version of the API the local server speaks, which the hello carries so a page that
         * cannot talk to it says so.
         */
        public Builder api(int version) {
            this.api = version;
            return this;
        }

        /**
         * Where to say the relay is reached ({@code null}) or lost (why), the console. A drop is said
         * only once it has lasted half a minute.
         */
        public Builder say(Consumer<String> say) {
            this.say = say;
            return this;
        }

        /**
         * Request headers carried to the local server besides {@code Content-Type} and
         * {@code Accept}. Every other header the page sends is dropped.
         */
        public Builder carry(String... headers) {
            for (var header : headers) carried.add(header.toLowerCase(Locale.ROOT));
            return this;
        }

        /** Answer headers carried back besides {@code Content-Type} and {@code Cache-Control}. */
        public Builder returns(String... headers) {
            for (var header : headers) returned.add(header.toLowerCase(Locale.ROOT));
            return this;
        }

        /**
         * The paths whose answer is an endless stream: given a day rather than ten minutes, and not
         * counted as the link being used, since a page left open is not somebody using it.
         */
        public Builder streaming(Predicate<String> paths) {
            this.streaming = paths;
            return this;
        }

        /**
         * Told each time a tab opens a link: {@code false} the first time a server's own link is
         * opened, {@code true} each time a tab opens the public demo.
         */
        public Builder opened(Consumer<Boolean> told) {
            this.opened = told;
            return this;
        }

        /**
         * Makes this link the public demo's server rather than a session of the server's own: the
         * relay lets it be with the demo secret, and every tab that opens {@code /#demo} speaks
         * through this public key. The plugin must then answer as a demo and save nothing.
         *
         * @param key       the demo's key, sixteen bytes, the same the page's {@code demoKey} names
         * @param displaced told when another demo server took the demo over and this one let it go
         */
        public Builder demo(String secret, byte[] key, Runnable displaced) {
            if (key == null || key.length != 16) throw new IllegalArgumentException("A demo key is sixteen bytes");
            this.demoSecret = secret;
            this.demoKey = key.clone();
            this.displaced = displaced;
            return this;
        }

        /** Dials the relay and keeps dialing it while the link is open. */
        public RelayLink open() {
            return new RelayLink(this);
        }
    }

    private static final class Grant {
        private final byte[] key;
        private final String id;
        private final long expires;
        private final Supplier<Map<String, ?>> hello;
        private volatile String tab;
        private final long lifetime;
        private volatile long until;
        private final int number;
        private final String owner;
        private final UUID ownerId;
        private volatile long opened;
        /**
         * When a tab holding it last asked something, a streaming path aside: that is a page left
         * open, not somebody using it.
         */
        private volatile long used;
        private volatile String address;
        private volatile String country;
        /**
         * The public demo's link: any number of tabs, for as long as the editor is open. What it asks
         * is answered as a demo, whatever the server's own links may do.
         */
        private final boolean shared;

        private Grant(byte[] key, byte[] id, long expires, Supplier<Map<String, ?>> hello, long lifetime, int number, String owner,
                      UUID ownerId, boolean shared) {
            this.shared = shared;
            this.lifetime = lifetime;
            this.key = key;
            this.id = hex(id, 0, id.length);
            this.expires = expires;
            this.hello = hello;
            this.number = number;
            this.owner = owner;
            this.ownerId = ownerId;
        }
    }

    private static Set<String> union(Set<String> always, Set<String> more) {
        var all = new HashSet<>(always);
        all.addAll(more);
        return Set.copyOf(all);
    }

    private static java.util.concurrent.ThreadFactory daemon(String name) {
        return runnable -> {
            var thread = new Thread(runnable, name);
            thread.setDaemon(true);
            return thread;
        };
    }

    private static String trimSlash(String address) {
        return address.endsWith("/") ? address.substring(0, address.length() - 1) : address;
    }

    private static String text(JsonObject object, String name) {
        return object.has(name) && object.get(name).isJsonPrimitive() ? object.get(name).getAsString() : null;
    }

    private static void quietly(InputStream stream) {
        if (stream == null) return;
        try {
            stream.close();
        } catch (IOException ignored) {
        }
    }

    private static String rootMessage(Throwable failure) {
        var root = failure;
        while (root.getCause() != null) root = root.getCause();
        return root.getMessage() == null ? root.getClass().getSimpleName() : root.getMessage();
    }

    private static byte[] bytes(int length) {
        var out = new byte[length];
        RANDOM.nextBytes(out);
        return out;
    }

    private static String hex(byte[] bytes, int from, int length) {
        var out = new StringBuilder(length * 2);
        for (int i = from; i < from + length; i++) out.append(Character.forDigit((bytes[i] >> 4) & 15, 16)).append(Character.forDigit(bytes[i] & 15, 16));
        return out.toString();
    }

    private static String token(int length) {
        return encode(bytes(length));
    }

    private static String encode(byte[] bytes) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
